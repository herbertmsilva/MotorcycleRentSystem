﻿using MotorcycleRentalSystem.Application.Responses;
using Swashbuckle.AspNetCore.Filters;

namespace MotorcycleRentalSystem.Api.Examples
{
    public class GenericBadRequestExample : IExamplesProvider<ApiResponse<object>>
    {
        public ApiResponse<object> GetExamples()
        {
            return new ApiResponse<object>
            {
                Success = false,
                Message = "Validation failed for one or more fields. / Business validation error occurred.",
                Data = null,
                Errors = new List<ApiError>
                {
                    new ApiError(Guid.NewGuid(), "FieldName", "Validation error message.")
                }
            };
        }
    }
}
