﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRentalSystem.Core.Enums
{
    public enum LogLevel
    {
        Info,
        Warning,
        Error,
        Debug
    }
}
