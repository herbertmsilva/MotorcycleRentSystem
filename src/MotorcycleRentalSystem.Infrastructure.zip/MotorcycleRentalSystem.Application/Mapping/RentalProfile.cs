﻿using AutoMapper;
using MotorcycleRentalSystem.Application.UseCases.Rental.RentMotorcycle;
using MotorcycleRentalSystem.Core.Entities.Postgres;

namespace MotorcycleRentalSystem.Application.Mapping
{
    public class RentalProfile : Profile
    {
        public RentalProfile() { 
            CreateMap<RentMotorcycleCommand, RentalEntity>();
        }
    }
}
