﻿using MotorcycleRentalSystem.Core.Entities.Postgres;

namespace MotorcycleRentalSystem.Core.Interfaces
{
    public interface IRentalRepository : IRepositoryBase<RentalEntity>
    { 
    }
}
