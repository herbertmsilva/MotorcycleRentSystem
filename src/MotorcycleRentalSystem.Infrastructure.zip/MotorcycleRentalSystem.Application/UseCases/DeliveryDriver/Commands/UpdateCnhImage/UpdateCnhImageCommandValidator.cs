﻿using FluentValidation;

namespace MotorcycleRentalSystem.Application.UseCases.DeliveryDriver.Commands.UpdateCnhImage
{
    public class UpdateCnhImageCommandValidator : AbstractValidator<UpdateCnhImageCommand>
    {
        public UpdateCnhImageCommandValidator()
        {
            RuleFor(x => x.CnhImageStream)
                .NotNull().WithMessage("CNH image stream is required.")
                .Must(BeAValidSize).WithMessage("The image size must be less than 5 MB.");

            RuleFor(x => x.FileName)
                .NotEmpty().WithMessage("File name is required.")
                .Must(BeAValidImageType).WithMessage("Only PNG or BMP images are allowed.");
        }

        private bool BeAValidImageType(string fileName)
        {
            var allowedExtensions = new[] { ".png", ".bmp" };
            var fileExtension = Path.GetExtension(fileName).ToLowerInvariant();
            return allowedExtensions.Contains(fileExtension);
        }

        private bool BeAValidSize(Stream cnhImageStream)
        {
            const long maxSizeInBytes = 5 * 1024 * 1024; // 5 MB
            try
            {
                if (cnhImageStream.Length <= maxSizeInBytes)
                {
                    return true;
                }
            }
            catch
            {
                return false; 
            }
            return false;
        }
    }
}
