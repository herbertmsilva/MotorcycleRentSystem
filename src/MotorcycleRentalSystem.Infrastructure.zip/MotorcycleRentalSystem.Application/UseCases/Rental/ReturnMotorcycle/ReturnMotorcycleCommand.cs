﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRentalSystem.Application.UseCases.Rental.ReturnMotorcycle
{
    public class ReturnMotorcycleCommand : IRequest<decimal>
    {
        public Guid RentalId { get; set; }
        public DateTime ReturnDate { get; set; }
    }
}
