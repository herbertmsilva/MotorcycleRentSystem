﻿using AutoMapper;
using MediatR;
using MotorcycleRentalSystem.Application.Exceptions;
using MotorcycleRentalSystem.Core.Entities.Postgres;
using MotorcycleRentalSystem.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRentalSystem.Application.UseCases.Rental.RentMotorcycle
{
    public class RentMotorcycleCommandHandler(IRentalRepository _rentalRepository, 
        IDeliveryDriverRepository _driverRepository, 
        IMotorcycleRepository _motorcycleRepository,
        IMapper _mapper)
        : IRequestHandler<RentMotorcycleCommand, Guid>
    {
        public async Task<Guid> Handle(RentMotorcycleCommand request, CancellationToken cancellationToken)
        {
            var driver = await _driverRepository.GetByIdAsync(request.DeliveryDriverId);
            if (driver == null || !driver.CNHType.Contains("A"))
            {
                throw new BusinessValidationException("Only drivers with a type A license can rent a motorcycle.");
            }

            var motorcycle = await _motorcycleRepository.GetByIdAsync(request.MotorcycleId);
            if (motorcycle == null)
            {
                throw new NotFoundException("Motorcycle not found.");
            }

            decimal dailyRate = CalculateDailyRate(request.RentalDays);

            var startDate = DateTime.Now.AddDays(1); // Locação começa no dia seguinte
            var endDate = startDate.AddDays(request.RentalDays);

            var rental = _mapper.Map<RentalEntity>(request);

            await _rentalRepository.AddAsync(rental);

            return rental.Id;
        }

        private decimal CalculateDailyRate(int rentalDays)
        {
            return rentalDays switch
            {
                7 => 30m,
                15 => 28m,
                30 => 22m,
                45 => 20m,
                50 => 18m,
                _ => throw new ArgumentException("Invalid rental period.")
            };
        }
    }
}
