﻿using MotorcycleRentalSystem.Core.Entities.Postgres;

namespace MotorcycleRentalSystem.Core.Interfaces
{
    public interface IDeliveryDriverRepository : IRepositoryBase<DeliveryDriverEntity>
    {
    }
}
