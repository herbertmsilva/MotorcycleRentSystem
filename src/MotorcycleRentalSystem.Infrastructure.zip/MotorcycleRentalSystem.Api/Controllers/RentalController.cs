﻿using Microsoft.AspNetCore.Mvc;
using MediatR;
using MotorcycleRentalSystem.Application.UseCases.Rental.RentMotorcycle;
using MotorcycleRentalSystem.Application.UseCases.Rental.ReturnMotorcycle;
using Asp.Versioning;

namespace MotorcycleRentalSystem.Api.Controllers
{
    /// <summary>
    /// API para gerenciar locações de motos.
    /// </summary>
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class RentalController : ControllerBase
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Construtor para RentalController.
        /// </summary>
        /// <param name="mediator">Instância do Mediator para mediação de comandos.</param>
        public RentalController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Endpoint para alugar uma moto.
        /// </summary>
        /// <param name="command">Comando contendo os detalhes do aluguel.</param>
        /// <returns>Retorna o ID do aluguel recém-criado.</returns>
        /// <response code="201">Aluguel criado com sucesso.</response>
        /// <response code="400">Se os dados do aluguel forem inválidos.</response>
        [HttpPost("rent")]
        [ProducesResponseType(typeof(Guid), 201)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> RentMotorcycle([FromBody] RentMotorcycleCommand command)
        {
            var rentalId = await _mediator.Send(command);
            return CreatedAtAction(nameof(RentMotorcycle), new { id = rentalId }, rentalId);
        }

        /// <summary>
        /// Endpoint para devolver uma moto e calcular o valor total da locação.
        /// </summary>
        /// <param name="command">Comando contendo os detalhes da devolução.</param>
        /// <returns>Retorna o custo total da locação, incluindo multas, se houver.</returns>
        /// <response code="200">Devolução processada com sucesso.</response>
        /// <response code="400">Se os dados da devolução forem inválidos.</response>
        [HttpPost("return")]
        [ProducesResponseType(typeof(decimal), 200)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> ReturnMotorcycle([FromBody] ReturnMotorcycleCommand command)
        {
            var totalCost = await _mediator.Send(command);
            return Ok(totalCost);
        }
    }
}
