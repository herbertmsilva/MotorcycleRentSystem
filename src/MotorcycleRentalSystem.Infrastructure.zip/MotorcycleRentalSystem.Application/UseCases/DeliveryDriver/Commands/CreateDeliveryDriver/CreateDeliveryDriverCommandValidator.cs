﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRentalSystem.Application.UseCases.DeliveryDriver.Commands.CreateDeliveryDriver
{
    public class CreateDeliveryDriverCommandValidator : AbstractValidator<CreateDeliveryDriverCommand>
    {
        public CreateDeliveryDriverCommandValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("Name is required.")
                .MaximumLength(100).WithMessage("Name cannot be longer than 100 characters.");

            RuleFor(x => x.CNPJ)
                .NotEmpty().WithMessage("CNPJ is required.")
                .Length(14).WithMessage("CNPJ must be 14 characters long."); 

            RuleFor(x => x.BirthDate)
                .NotEmpty().WithMessage("Date of birth is required.")
                .LessThan(DateTime.Today).WithMessage("Date of birth must be in the past.");

            RuleFor(x => x.CNHNumber)
                .NotEmpty().WithMessage("CNH number is required.")
                .Length(11).WithMessage("CNH number must be 11 characters long.");

            RuleFor(x => x.CNHType)
                .NotEmpty().WithMessage("CNH type is required.")
                .Must(type => type == "A" || type == "B" || type == "A+B").WithMessage("CNH type must be 'A', 'B', or 'A+B'.");
        }
    }
}
