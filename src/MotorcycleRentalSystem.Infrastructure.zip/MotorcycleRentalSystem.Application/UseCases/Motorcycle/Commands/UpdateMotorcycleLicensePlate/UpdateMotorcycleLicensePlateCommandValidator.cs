﻿using FluentValidation;

namespace MotorcycleRentalSystem.Application.UseCases.Motorcycle.Commands.UpdateMotorcycleLicensePlate
{
    public class UpdateMotorcycleLicensePlateCommandValidator : AbstractValidator<UpdateMotorcycleLicensePlateCommand>
    {
        public UpdateMotorcycleLicensePlateCommandValidator()
        {
            RuleFor(x => x.NewLicensePlate)
            .NotEmpty().WithMessage("License plate is required.")
            .Matches(@"^[A-Z]{3}[0-9][A-Z][0-9]{2}$|^[A-Z]{3}[0-9]{4}$")
            .WithMessage("License plate must be in a valid format (e.g., ABC1234 or ABC1D23).")
            .MaximumLength(7).WithMessage("License plate cannot be longer than 7 characters.");
        }
    }
}
