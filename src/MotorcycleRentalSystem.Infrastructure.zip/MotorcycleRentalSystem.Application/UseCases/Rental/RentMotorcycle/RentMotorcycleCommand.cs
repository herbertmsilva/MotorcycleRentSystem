﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotorcycleRentalSystem.Application.UseCases.Rental.RentMotorcycle
{
    public class RentMotorcycleCommand : IRequest<Guid>
    {
        public Guid DeliveryDriverId { get; set; }
        public Guid MotorcycleId { get; set; }
        public int RentalDays { get; set; }
    }
}
