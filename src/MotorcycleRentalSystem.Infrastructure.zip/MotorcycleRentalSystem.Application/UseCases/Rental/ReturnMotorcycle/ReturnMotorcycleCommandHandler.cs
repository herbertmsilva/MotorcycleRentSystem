﻿using MediatR;
using MotorcycleRentalSystem.Application.Exceptions;
using MotorcycleRentalSystem.Application.UseCases.Rental.ReturnMotorcycle;
using MotorcycleRentalSystem.Core.Entities.Postgres;
using MotorcycleRentalSystem.Core.Interfaces;

namespace MotorcycleRentalSystem.Application.UseCases.Rental.Commands
{
    public class ReturnMotorcycleCommandHandler(IRentalRepository _rentalRepository) : IRequestHandler<ReturnMotorcycleCommand, decimal>
    {
        public async Task<decimal> Handle(ReturnMotorcycleCommand request, CancellationToken cancellationToken)
        {
            var rental = await _rentalRepository.GetByIdAsync(request.RentalId);
            if (rental == null)
            {
                throw new NotFoundException("Rental not found.");
            }

            decimal penalty = CalculatePenalty(request.ReturnDate, rental);

            rental.TotalCost += penalty;
            rental.IsCompleted = true;

            await _rentalRepository.UpdateAsync(rental);

            return rental.TotalCost;
        }

        private decimal CalculatePenalty(DateTime returnDate, RentalEntity rental)
        {
            if (returnDate < rental.ExpectedEndDate)
            {
                var daysEarly = (rental.ExpectedEndDate - returnDate).Days;
                decimal penaltyRate = rental.RentalDays == 7 ? 0.20m : 0.40m;
                return daysEarly * rental.DailyRate * penaltyRate;
            }
            else if (returnDate > rental.ExpectedEndDate)
            {
                var daysLate = (returnDate - rental.ExpectedEndDate).Days;
                return daysLate * 50m; 
            }
            return 0m;
        }
    }
}
